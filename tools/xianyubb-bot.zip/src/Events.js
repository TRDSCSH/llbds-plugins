"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.echo = exports.wsevent = exports.bot = void 0;
const events_1 = require("events");
exports.bot = new events_1.EventEmitter();
exports.wsevent = new events_1.EventEmitter();
exports.echo = new events_1.EventEmitter();
//# sourceMappingURL=Events.js.map