
const bot = require("../app").bot
const Plugin = require("../src/plugins").Plugins

let example = new Plugin("plugin_name", "description", [0, 1, 0], {
    otherinformation: ""
})
bot.BotEvents.on("onReceiveGroupMessage", (msg) => {
    console.log(msg)
})

bot.get_login_info().then((v) => {
    console.log(v)
}).catch((err) => {
    console.log(err)
})